class UIManager {
    showMessage(message, type = 'success') {
      const messageEl = document.getElementById('status-message');
      messageEl.textContent = message;
      messageEl.className = `status-message status-${type}`;
      messageEl.style.display = 'block';

      setTimeout(() => {
        messageEl.style.display = 'none';
      }, 3000);
    }
  }

  // Initialize the application
  let app, legendManager, markerManager, uiManager;

  document.addEventListener('DOMContentLoaded', () => {
    app = new InteractiveMap();
    legendManager = app.legendManager;
    markerManager = app.markerManager;
    uiManager = app.uiManager;
  });