class InteractiveMap {
    constructor() {
      this.map = null;
      this.legendManager = null;
      this.markerManager = null;
      this.uiManager = null;
      this.init();
    }

    init() {
      this.initializeMap();
      this.legendManager = new LegendManager();
      this.markerManager = new MarkerManager(this.map, this.legendManager);
      this.uiManager = new UIManager();
      this.bindEvents();
    }

    initializeMap() {
      this.map = L.map('map').setView([-6.2, 106.8], 10);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(this.map);
    }

    bindEvents() {
      this.map.on('click', (e) => {
        const selectedType = document.getElementById('legend-select').value;
        if (!selectedType || !this.legendManager.legendItems[selectedType]) {
          this.uiManager.showMessage("Please select a legend type first.", 'error');
          return;
        }
        this.markerManager.createMarker(e.latlng, selectedType);
      });

      // Hide context menu on click
      document.addEventListener('click', () => {
        document.getElementById('marker-menu').style.display = 'none';
      });

      // Shape selection change handler
      document.getElementById('shape-select').addEventListener('change', (e) => {
        this.legendManager.toggleCustomIconUpload(e.target.value === 'custom');
      });

      // Icon upload handler
      document.getElementById('icon-upload').addEventListener('change', (e) => {
        this.legendManager.handleIconUpload(e);
      });
    }
  }